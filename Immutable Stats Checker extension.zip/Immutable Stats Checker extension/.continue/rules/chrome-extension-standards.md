---
globs: "*.js"
alwaysApply: true
---

Follow Chrome Extension best practices: use proper CSP-compatible code, handle Chrome APIs safely with error checks, use manifest v3 standards, and ensure all async operations have proper error handling