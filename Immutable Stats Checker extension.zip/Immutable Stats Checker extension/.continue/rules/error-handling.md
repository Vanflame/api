---
globs: "*.js"
alwaysApply: true
---

Always wrap async operations in try-catch blocks, provide meaningful error messages, and handle edge cases gracefully. Log errors with context for debugging.