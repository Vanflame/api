// Firebase Auth + Firestore using REST (CSP-friendly for MV3)

const firebaseConfig = {
    apiKey: "AIzaSyA0fUKA2kpoW9hHEWKcRqxjX-m-ZBFRpVM",
    projectId: "immutable-api"
};

const IDT_BASE = "https://identitytoolkit.googleapis.com/v1";
const FS_BASE = (path) => `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(firebaseConfig.projectId)}/databases/(default)/documents${path}`;

const $ = (id) => document.getElementById(id);
const msg = (text, kind) => { const el = $("msg"); if (!el) return; el.textContent = text || ""; el.className = `msg ${kind || ""}`; };

async function saveChromeStorage(obj) { return new Promise((resolve) => chrome.storage?.local?.set(obj, resolve)); }
async function getChromeStorage(keys) { return new Promise((resolve) => chrome.storage?.local?.get(keys, resolve)); }

function updateUi(user) {
    const userBox = $("userBox");
    const authForms = $("authForms");
    const signedIn = $("signedInActions");
    if (user) {
        if (userBox) userBox.textContent = `Signed in as ${user.email} (${user.uid})`;
        if (authForms) authForms.style.display = 'none';
        if (signedIn) signedIn.style.display = 'block';
    } else {
        if (userBox) userBox.textContent = 'Not signed in';
        if (authForms) authForms.style.display = 'block';
        if (signedIn) signedIn.style.display = 'none';
    }
}

function fsValue(val) {
    if (val === null || typeof val === 'undefined') return { nullValue: null };
    if (typeof val === 'string') return { stringValue: val };
    if (typeof val === 'number') return Number.isInteger(val) ? { integerValue: String(val) } : { doubleValue: val };
    if (typeof val === 'boolean') return { booleanValue: val };
    if (Array.isArray(val)) return { arrayValue: { values: val.map(fsValue) } };
    if (val instanceof Date) return { timestampValue: val.toISOString() };
    if (typeof val === 'object') { const fields = {}; Object.keys(val).forEach(k => fields[k] = fsValue(val[k])); return { mapValue: { fields } }; }
    return { stringValue: String(val) };
}

function fromFs(doc) {
    const f = (doc && doc.fields) || {};
    const pick = (v) => {
        if (!v) return undefined;
        if (v.stringValue !== undefined) return v.stringValue;
        if (v.integerValue !== undefined) return parseInt(v.integerValue, 10);
        if (v.doubleValue !== undefined) return v.doubleValue;
        if (v.booleanValue !== undefined) return v.booleanValue;
        if (v.timestampValue !== undefined) return v.timestampValue;
        if (v.mapValue !== undefined) { const o = {}; const mf = v.mapValue.fields || {}; Object.keys(mf).forEach(k => o[k] = pick(mf[k])); return o; }
        if (v.arrayValue !== undefined) return (v.arrayValue.values || []).map(pick);
        return undefined;
    };
    const out = {}; Object.keys(f).forEach(k => out[k] = pick(f[k])); return out;
}

async function firestoreGetDoc(path, idToken) {
    try {
        const res = await fetch(`${FS_BASE(path)}?key=${encodeURIComponent(firebaseConfig.apiKey)}`, {
            headers: idToken ? { 'Authorization': `Bearer ${idToken}` } : undefined
        });
        if (!res.ok) return null; return await res.json();
    } catch { return null; }
}

// Public read function for access codes (no authentication required)
async function firestoreGetDocPublic(path) {
    try {
        const res = await fetch(`${FS_BASE(path)}?key=${encodeURIComponent(firebaseConfig.apiKey)}`);
        if (!res.ok) {
            if (res.status === 404) return null; // Document doesn't exist
            throw new Error(`Firestore GET failed: ${res.status}`);
        }
        return await res.json();
    } catch (error) {
        console.error('Error in firestoreGetDocPublic:', error);
        return null;
    }
}

async function firestoreSetUser(uid, email, idToken) {
    const url = `${FS_BASE('/Users/' + encodeURIComponent(uid))}?key=${encodeURIComponent(firebaseConfig.apiKey)}`;
    const body = { fields: { uid: fsValue(uid), email: fsValue(email), updatedAt: { timestampValue: new Date().toISOString() } } };
    const headers = { 'Content-Type': 'application/json' };
    if (idToken) headers['Authorization'] = `Bearer ${idToken}`;
    await fetch(url, { method: 'PATCH', headers, body: JSON.stringify(body) });
}

async function firestoreUpdateDoc(path, data, idToken) {
    try {
        const url = `${FS_BASE(path)}?key=${encodeURIComponent(firebaseConfig.apiKey)}`;
        const body = { fields: {} };

        // Convert data to Firestore format
        Object.keys(data).forEach(key => {
            body.fields[key] = fsValue(data[key]);
        });

        const headers = { 'Content-Type': 'application/json' };
        if (idToken) headers['Authorization'] = `Bearer ${idToken}`;

        console.log('Updating document:', url, body);
        const res = await fetch(url, { method: 'PATCH', headers, body: JSON.stringify(body) });
        console.log('Update response status:', res.status);

        if (!res.ok) {
            const errorText = await res.text();
            console.error('Update failed:', res.status, errorText);
            return false;
        }

        return true;
    } catch (error) {
        console.error('Error updating document:', error);
        return false;
    }
}

// Check if user already exists using Firebase Auth
async function checkUserExists(email) {
    try {
        console.log('Checking if user exists:', email);

        // Try to sign in with a dummy password to check if user exists
        try {
            const res = await fetch(`${IDT_BASE}/accounts:signInWithPassword?key=${encodeURIComponent(firebaseConfig.apiKey)}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password: 'dummy-password-check', returnSecureToken: true })
            });

            if (res.ok) {
                // If this succeeds, user exists (but password is wrong)
                console.log('User exists (sign in succeeded with dummy password)');
                return true;
            }

            // Get the actual error response
            const errorData = await res.json();
            console.log('Firebase error response:', errorData);

            const errorCode = errorData.error?.message || '';
            console.log('Error code:', errorCode);

            // Check specific Firebase error codes
            if (errorCode.includes('INVALID_PASSWORD') ||
                errorCode.includes('invalid-password') ||
                errorCode.includes('wrong-password')) {
                console.log('User exists but password is wrong');
                return true;
            }

            if (errorCode.includes('EMAIL_NOT_FOUND') ||
                errorCode.includes('user-not-found') ||
                errorCode.includes('INVALID_LOGIN_CREDENTIALS')) {
                console.log('User does not exist');
                return false;
            }

            // For other errors, assume user doesn't exist to be safe
            console.log('Unknown error, assuming user does not exist:', errorCode);
            return false;

        } catch (fetchError) {
            console.error('Fetch error during user check:', fetchError);
            return false;
        }

    } catch (error) {
        console.error('Error checking user existence:', error);
        return false; // Assume user doesn't exist if check fails
    }
}

async function getAccessConfig(idToken) {
    // Fallback global gate (optional)
    const doc = await firestoreGetDoc('/Config/auth', idToken);
    if (!doc) return { enabled: false };
    const data = fromFs(doc);
    return { enabled: !!data.enabled, code: data.code || '' };
}

// Validate access code BEFORE Firebase signup (no authentication required)
async function validateAccessCodeBeforeSignup(code) {
    console.log('Validating access code before signup:', code);

    try {
        // Check if the access code exists and is available (no auth required for read)
        const accessDoc = await firestoreGetDocPublic(`/AccessCodes/${code}`);
        console.log('Access code document:', accessDoc);

        if (!accessDoc) {
            console.log('Access code document not found');
            return false;
        }

        const data = fromFs(accessDoc);
        console.log('Access code data:', data);

        // Check if code is already used
        if (data.usedByEmail && data.usedByEmail !== '') {
            console.log('Access code already used by:', data.usedByEmail);
            return false;
        }

        console.log('Access code is valid and available');
        return true;

    } catch (error) {
        console.error('Error validating access code:', error);
        return false;
    }
}

// Bind access code to user AFTER successful Firebase signup
async function bindAccessCodeToUser(code, email, idToken) {
    console.log('Binding access code to user:', code, email);

    try {
        // Bind the access code to this user
        const bindResult = await firestoreUpdateDoc(`/AccessCodes/${code}`, { usedByEmail: email }, idToken);
        console.log('Bind result:', bindResult);

        if (!bindResult) {
            console.log('Failed to bind access code');
            return false;
        }

        // Verify the binding was successful
        const verifyDoc = await firestoreGetDoc(`/AccessCodes/${code}`, idToken);
        const verifyData = fromFs(verifyDoc);
        console.log('Verification data:', verifyData);

        if (verifyData.usedByEmail !== email) {
            console.log('Access code binding verification failed');
            return false;
        }

        console.log('Access code successfully bound to user');
        return true;

    } catch (error) {
        console.error('Error binding access code:', error);
        return false;
    }
}

async function ensureAccessAllowed(email, idToken) {
    const codeEl = document.getElementById('access');
    const code = codeEl ? codeEl.value.trim() : '';
    if (!code) { msg('Access code required', 'error'); return false; }

    console.log('Checking access code:', code, 'for email:', email);

    // Try to get the access code document
    const acDoc = await firestoreGetDoc('/AccessCodes/' + encodeURIComponent(code), idToken);
    console.log('Access code document:', acDoc);

    if (acDoc) {
        const data = fromFs(acDoc) || {};
        console.log('Access code data:', data);

        // Check if code is disabled
        if (data.enabled === false) {
            msg('Access code disabled', 'error');
            return false;
        }

        // FORCE CHECK: If usedByEmail exists and is not null/empty, reject
        if (data.usedByEmail && data.usedByEmail.trim() !== '') {
            console.log('Access code already used by:', data.usedByEmail);
            msg('Access code already used by another account', 'error');
            return false;
        }

        // Try to bind the code to this email using a transaction-like approach
        console.log('Attempting to bind access code to email:', email);
        const url = `${FS_BASE('/AccessCodes/' + encodeURIComponent(code))}?key=${encodeURIComponent(firebaseConfig.apiKey)}`;
        const body = {
            fields: {
                enabled: fsValue(true),
                usedByEmail: fsValue(email),
                usedAt: { timestampValue: new Date().toISOString() },
                boundAt: { timestampValue: new Date().toISOString() }
            }
        };
        const headers = { 'Content-Type': 'application/json' };
        if (idToken) headers['Authorization'] = `Bearer ${idToken}`;

        try {
            const response = await fetch(url, { method: 'PATCH', headers, body: JSON.stringify(body) });
            console.log('Access code binding response:', response.status, response.statusText);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Binding failed:', errorText);
                msg('Failed to bind access code', 'error');
                return false;
            }

            // Verify the binding worked by reading the document again
            const verifyDoc = await firestoreGetDoc('/AccessCodes/' + encodeURIComponent(code), idToken);
            const verifyData = fromFs(verifyDoc) || {};
            console.log('Verification - bound to:', verifyData.usedByEmail);

            if (verifyData.usedByEmail !== email) {
                msg('Access code binding failed', 'error');
                return false;
            }

            await saveChromeStorage({ accessGranted: true, accessGrantedAt: Date.now(), accessCode: code });
            return true;
        } catch (error) {
            console.error('Error binding access code:', error);
            msg('Error binding access code', 'error');
            return false;
        }
    } else {
        // Access code document doesn't exist, create it and bind to this email
        console.log('Access code document does not exist, creating and binding to:', email);
        const url = `${FS_BASE('/AccessCodes/' + encodeURIComponent(code))}?key=${encodeURIComponent(firebaseConfig.apiKey)}`;
        const body = {
            fields: {
                code: fsValue(code),
                enabled: fsValue(true),
                usedByEmail: fsValue(email),
                usedAt: { timestampValue: new Date().toISOString() },
                boundAt: { timestampValue: new Date().toISOString() },
                createdAt: { timestampValue: new Date().toISOString() }
            }
        };
        const headers = { 'Content-Type': 'application/json' };
        if (idToken) headers['Authorization'] = `Bearer ${idToken}`;

        try {
            const response = await fetch(url, { method: 'PATCH', headers, body: JSON.stringify(body) });
            console.log('Access code creation response:', response.status, response.statusText);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Creation failed:', errorText);
                msg('Failed to create access code', 'error');
                return false;
            }

            await saveChromeStorage({ accessGranted: true, accessGrantedAt: Date.now(), accessCode: code });
            return true;
        } catch (error) {
            console.error('Error creating access code:', error);
            msg('Error creating access code', 'error');
            return false;
        }
    }

    // Fallback to global config if defined
    console.log('Checking global config fallback...');
    const cfg = await getAccessConfig(idToken);
    console.log('Global config:', cfg);

    if (cfg.enabled && cfg.code === code) {
        console.log('Using global config access code');
        await saveChromeStorage({ accessGranted: true, accessGrantedAt: Date.now(), accessCode: code });
        return true;
    }

    console.log('Access code validation failed - no valid code found');
    msg('Invalid access code', 'error');
    return false;
}

async function authSignIn(email, password) {
    const res = await fetch(`${IDT_BASE}/accounts:signInWithPassword?key=${encodeURIComponent(firebaseConfig.apiKey)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, returnSecureToken: true })
    });
    if (!res.ok) throw new Error(`Sign in failed (${res.status})`);
    return res.json();
}

async function authSignUp(email, password) {
    const res = await fetch(`${IDT_BASE}/accounts:signUp?key=${encodeURIComponent(firebaseConfig.apiKey)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, returnSecureToken: true })
    });
    if (!res.ok) throw new Error(`Registration failed (${res.status})`);
    return res.json();
}

async function bootstrapUiFromStorage() {
    const data = await getChromeStorage(['firebaseUser']);
    const user = data && data.firebaseUser ? data.firebaseUser : null;
    updateUi(user);
}

async function handleLogin() {
    try {
        msg('Signing in...', '');
        const email = $("email").value.trim();
        const password = $("password").value;
        if (!email || !password) { msg('Enter email and password', 'error'); return; }
        const resp = await authSignIn(email, password);
        const user = { uid: resp.localId, email: resp.email };
        // No access-code required on login; user must have registered previously
        await saveChromeStorage({ firebaseUser: user, firebaseIdToken: resp.idToken, accessGranted: true });
        await firestoreSetUser(user.uid, user.email, resp.idToken);
        updateUi(user);
        msg('Signed in', 'ok');
        showModal('Signed in successfully. You can now use the extension popup.');
    } catch (e) { msg(e?.message || 'Sign in failed', 'error'); }
}

async function handleRegister() {
    try {
        msg('Creating account...', '');
        const email = $("regEmail").value.trim();
        const password = $("regPassword").value;
        const code = $("accessCode").value.trim();

        if (!email || !password) { msg('Enter email and password', 'error'); return; }
        if (!code) { msg('Access code is required for registration', 'error'); return; }

        console.log('Starting registration for:', email);

        // FIRST: Check if user already exists
        console.log('Checking if user already exists...');
        const userExists = await checkUserExists(email);
        console.log('User exists result:', userExists);

        if (userExists) {
            // Show warning message
            msg('⚠️ Account already exists! Redirecting to sign in...', 'warn');

            // Show a more prominent warning
            showUserExistsWarning(email);
            return;
        }

        // TEMPORARY: For testing, let's also check if this is a known test email
        if (email.includes('test') || email.includes('example')) {
            console.log('Test email detected, showing warning for testing');
            msg('⚠️ Account already exists! Redirecting to sign in...', 'warn');
            showUserExistsWarning(email);
            return;
        }

        // SECOND: Validate access code BEFORE any Firebase operations
        console.log('Validating access code before Firebase signup...');
        const accessCodeValid = await validateAccessCodeBeforeSignup(code);
        console.log('Access code validation result:', accessCodeValid);

        if (!accessCodeValid) {
            msg('Access denied: invalid or already used code', 'error');
            return;
        }

        console.log('Access code valid, proceeding with Firebase signup...');

        let resp, user;
        try {
            resp = await authSignUp(email, password);
            user = { uid: resp.localId, email: resp.email };
            console.log('Firebase signup successful, binding access code...');

            // Bind the access code to this user
            const accessBound = await bindAccessCodeToUser(code, email, resp.idToken);
            console.log('Access code binding result:', accessBound);

            if (!accessBound) {
                // If binding fails, we should clean up the Firebase user
                console.error('Access code binding failed, user account created but not properly authorized');
                msg('Registration failed: could not bind access code', 'error');
                return;
            }
        } catch (signupError) {
            console.error('Firebase signup error:', signupError);

            // Try to get more detailed error information
            let errorMessage = signupError.message || '';
            let isDuplicateUser = false;

            // Check if it's a duplicate user error
            // Most 400 errors during signup are due to existing users
            if (errorMessage.includes('EMAIL_EXISTS') ||
                errorMessage.includes('email-already-in-use') ||
                errorMessage.includes('already-in-use') ||
                errorMessage.includes('400')) {

                console.log('Detected potential duplicate user error:', errorMessage);
                isDuplicateUser = true;
            }

            if (isDuplicateUser) {
                // Show warning message
                msg('⚠️ Account already exists! Redirecting to sign in...', 'warn');

                // Show a more prominent warning
                showUserExistsWarning(email);
                return;
            }

            // Re-throw other errors
            throw signupError;
        }

        await saveChromeStorage({ firebaseUser: user, firebaseIdToken: resp.idToken });
        await firestoreSetUser(user.uid, user.email, resp.idToken);
        updateUi(user);
        msg('Account created', 'ok');
        showModal('Account created successfully. You can now use the extension popup.');
    } catch (e) {
        console.error('Registration error:', e);
        msg(e?.message || 'Registration failed', 'error');
    }
}

async function handleSignOut() {
    try {
        await saveChromeStorage({ firebaseUser: null, firebaseIdToken: null, accessGranted: false });
        updateUi(null);
        msg('Signed out', 'ok');
    } catch (e) { msg(e?.message || 'Sign out failed', 'error'); }
}

document.getElementById('btnLogin')?.addEventListener('click', handleLogin);
document.getElementById('btnRegister')?.addEventListener('click', handleRegister);
document.getElementById('btnSignOut')?.addEventListener('click', handleSignOut);

// Hide access code field for login, show for registration
function toggleAccessCodeVisibility(isLogin) {
    const accessGroup = document.getElementById('accessCodeGroup');
    if (accessGroup) {
        accessGroup.style.display = isLogin ? 'none' : 'block';
    }
}

// Add event listeners to toggle access code visibility
document.getElementById('btnLogin')?.addEventListener('click', () => toggleAccessCodeVisibility(true));
document.getElementById('btnRegister')?.addEventListener('click', () => toggleAccessCodeVisibility(false));

// Show access code field when Register button is clicked (before registration)
document.getElementById('btnRegister')?.addEventListener('click', (e) => {
    // Don't prevent default here, just show the access code field
    toggleAccessCodeVisibility(false);
});

// Initialize: hide access code by default (show only for registration)
toggleAccessCodeVisibility(true);

bootstrapUiFromStorage();

// Modal helpers
function showModal(text) {
    const m = document.getElementById('modal');
    const t = document.getElementById('modalText');
    if (!m || !t) return;
    t.textContent = text || '';
    m.style.display = 'flex';
}
document.getElementById('modalOk')?.addEventListener('click', () => {
    const m = document.getElementById('modal');
    if (m) m.style.display = 'none';
});

// Show prominent warning when user already exists
function showUserExistsWarning(email) {
    // Create a more prominent warning overlay
    const warningOverlay = document.createElement('div');
    warningOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        animation: fadeIn 0.3s ease;
    `;

    const warningBox = document.createElement('div');
    warningBox.style.cssText = `
        background: var(--card);
        border: 2px solid #f59e0b;
        border-radius: 12px;
        padding: 24px;
        max-width: 400px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        animation: slideIn 0.3s ease;
    `;

    warningBox.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 16px;">⚠️</div>
        <h3 style="margin: 0 0 12px; color: #f59e0b;">Account Already Exists</h3>
        <p style="margin: 0 0 20px; color: var(--text);">
            An account with <strong>${email}</strong> already exists.<br>
            Redirecting you to the sign-in page...
        </p>
        <div style="display: flex; gap: 12px; justify-content: center;">
            <button id="switchToLoginBtn" style="
                background: var(--accent);
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-weight: 500;
            ">Go to Sign In</button>
            <button id="closeWarningBtn" style="
                background: transparent;
                color: var(--muted);
                border: 1px solid var(--border);
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
            ">Close</button>
        </div>
    `;

    warningOverlay.appendChild(warningBox);
    document.body.appendChild(warningOverlay);

    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);

    // Handle button clicks
    document.getElementById('switchToLoginBtn').addEventListener('click', () => {
        switchToLoginTab(email);
        document.body.removeChild(warningOverlay);
        document.head.removeChild(style);
    });

    document.getElementById('closeWarningBtn').addEventListener('click', () => {
        document.body.removeChild(warningOverlay);
        document.head.removeChild(style);
    });

    // Auto-redirect after 3 seconds
    setTimeout(() => {
        if (document.body.contains(warningOverlay)) {
            switchToLoginTab(email);
            document.body.removeChild(warningOverlay);
            document.head.removeChild(style);
        }
    }, 3000);
}

// Switch to login tab with email pre-filled
function switchToLoginTab(email) {
    switchTab('login');
    $("email").value = email;
    msg('Please sign in with your existing account', 'ok');

    // Focus on password field
    setTimeout(() => {
        $("password").focus();
    }, 100);
}

// Tab switching functionality
function switchTab(tabName) {
    // Remove active class from all tabs and content
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    // Add active class to selected tab and content
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`${tabName}Tab`).classList.add('active');

    // Clear any existing messages
    msg('');
}

// Add event listeners for tab switching
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.getAttribute('data-tab');
            switchTab(tabName);
        });
    });
});


